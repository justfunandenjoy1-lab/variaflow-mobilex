# VariaFlow Mobile

**VariaFlow Mobile** is a completely offline, local Android video conversion and optimization tool.

## Features

- ✅ Local video processing with FFmpeg (no internet required)
- ✅ Video information extraction (resolution, codec, bitrate, FPS, etc.)
- ✅ Format conversion (MP4, MKV, MOV)
- ✅ Resolution / FPS / codec / bitrate controls
- ✅ Audio codec, bitrate, sample rate, channel controls
- ✅ Presets: High Quality, Balanced, Small File, Custom
- ✅ Quality protection warnings before processing
- ✅ Before/After comparison screen
- ✅ Batch processing (multiple videos)
- ✅ Progress indicator with stage display
- ✅ Cancel processing
- ✅ Dark/light theme
- ✅ No login, no activation, no cloud, no analytics

## Requirements

- Android 7.0 (API 24) or higher
- ~200 MB free storage for temporary processing
- No internet connection needed

## Build Instructions

### Prerequisites

1. **Android Studio** (latest stable, e.g., Ladybug or newer)
2. **JDK 17** (bundled with Android Studio)
3. **Android SDK 36** installed

### Steps

1. **Clone / Copy** the project into a folder.
2. Open the project in **Android Studio**.
3. Wait for Gradle sync to complete (first sync downloads FFmpegKit native libraries).
4. Connect an Android device or start an emulator.
5. Click **Run ▶** to install the debug build.

### Build APK from Command Line

```bash
# Debug APK
./gradlew assembleDebug

# Release APK (unsigned)
./gradlew assembleRelease