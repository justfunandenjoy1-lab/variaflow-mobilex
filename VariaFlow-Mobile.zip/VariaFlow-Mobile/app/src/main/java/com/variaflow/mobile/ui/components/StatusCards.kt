package com.variaflow.mobile.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun WarningCard(message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer
        )
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Warning, contentDescription = null,
                tint = MaterialTheme.colorScheme.onErrorContainer)
            Spacer(Modifier.width(8.dp))
            Column {
                Text("Quality Warning", style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                Text(message, style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onErrorContainer)
            }
        }
    }
}

@Composable
fun ErrorCard(message: String, detail: String = "") {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer
        )
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Error, contentDescription = null,
                tint = MaterialTheme.colorScheme.onErrorContainer)
            Spacer(Modifier.width(8.dp))
            Column {
                Text("Error", style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                Text(message, style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onErrorContainer)
                if (detail.isNotBlank()) {
                    Text(detail, style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.7f))
                }
            }
        }
    }
}

@Composable
fun InfoCard(message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Info, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(message, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun SettingsSummaryCard(
    settings: com.variaflow.mobile.data.model.ProcessingSettings,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Text("Processing Settings", style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold)
                Icon(Icons.Default.Settings, contentDescription = "Edit")
            }
            Text("Preset: ${settings.preset.label}", style = MaterialTheme.typography.bodyMedium)
            Text("Format: ${settings.outputFormat.label}  •  Resolution: ${settings.resolution.label}",
                style = MaterialTheme.typography.bodyMedium)
            Text("Codec: ${settings.videoCodec.label}  •  Audio: ${settings.audioCodec.label}",
                style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun OutputStatusCard(
    fileNames: List<String>,
    outputUris: List<android.net.Uri>,
    onOpenOutput: (android.net.Uri) -> Unit,
    onCompare: () -> Unit,
    onNew: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text("Processing Complete!", style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold)
            }

            Text("Saved to: Movies/VariaFlow/Output/", style = MaterialTheme.typography.bodyMedium)
            fileNames.forEach { name ->
                Text("• $name", style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium)
            }

            if (outputUris.isNotEmpty()) {
                Button(onClick = { onOpenOutput(outputUris.first()) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.OpenInNew, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Open Output")
                }
            }

            OutlinedButton(onClick = onCompare, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Compare, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Compare Before / After")
            }

            OutlinedButton(onClick = onNew, modifier = Modifier.fillMaxWidth()) {
                Text("Process Another Video")
            }
        }
    }
}