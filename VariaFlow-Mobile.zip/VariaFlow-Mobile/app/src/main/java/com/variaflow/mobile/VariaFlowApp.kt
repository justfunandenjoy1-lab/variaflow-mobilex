package com.variaflow.mobile

import android.app.Application

class VariaFlowApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize FFmpegKit if needed (optional)
        // FFmpegKitConfig.enableLogCallback(null) // Disable verbose logging in production
    }
}