package com.variaflow.mobile.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import com.variaflow.mobile.data.model.*
import com.variaflow.mobile.ui.components.*
import com.variaflow.mobile.viewmodel.MainViewModel
import androidx.compose.runtime.collectAsState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToSettings: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    // Permission launcher
    var hasPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
            } else {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasPermission = granted }

    // Video picker
    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val videoUris = uris.filter { uri ->
            context.contentResolver.getType(uri)?.startsWith("video/") == true
        }
        if (videoUris.isEmpty()) {
            viewModel.showSnackbar("No valid video files selected. Supported formats: MP4, MOV, MKV, AVI, WebM.")
        } else {
            viewModel.onVideoSelected(videoUris)
        }
    }

    // Storage permission for saving
    val savePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.processCurrentVideo()
        else viewModel.showSnackbar("Storage permission is required to save the output video.")
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("VariaFlow Mobile", fontWeight = FontWeight.Bold)
                        Text("Offline Video Processor", style = MaterialTheme.typography.labelMedium)
                    }
                },
                actions = {
                    if (state.videoInfos.size > 1) {
                        IconButton(onClick = { viewModel.navigateToBatch() }) {
                            Icon(Icons.Default.List, contentDescription = "Batch")
                        }
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        },
        snackbarHost = {
            SnackbarHost(hostState = remember { SnackbarHostState() }) { data ->
                Snackbar(snackbarData = data)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Select Video Button
            Button(
                onClick = {
                    if (!hasPermission) {
                        val perm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                            Manifest.permission.READ_MEDIA_VIDEO
                        else Manifest.permission.READ_EXTERNAL_STORAGE
                        permissionLauncher.launch(perm)
                    } else {
                        videoPicker.launch(arrayOf("video/*"))
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = MaterialTheme.shapes.medium
            ) {
                Icon(Icons.Default.VideoLibrary, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (state.videoInfos.isEmpty()) "Select Video" else "Select Different Video")
            }

            // Video Information
            state.currentVideoInfo?.let { info ->
                VideoInfoCard(info = info)

                // Quality Warning
                state.qualityWarning?.let { warning ->
                    WarningCard(message = warning)
                }
            }

            // Processing Settings Summary
            if (state.currentVideoInfo != null) {
                SettingsSummaryCard(
                    settings = state.settings,
                    onClick = onNavigateToSettings
                )
            }

            // Process Button
            if (state.currentVideoInfo != null &&
                state.processingState !is ProcessingState.Processing) {
                Button(
                    onClick = {
                        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
                            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            != PackageManager.PERMISSION_GRANTED) {
                            savePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        } else {
                            viewModel.processCurrentVideo()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Process Video", style = MaterialTheme.typography.titleLarge)
                }
            }

            // Progress / Status
            when (val ps = state.processingState) {
                is ProcessingState.Processing -> {
                    ProcessingProgressCard(
                        state = ps,
                        onCancel = { viewModel.cancelProcessing() }
                    )
                }
                is ProcessingState.Completed -> {
                    OutputStatusCard(
                        fileNames = ps.outputFileNames,
                        outputUris = ps.outputUris,
                        onOpenOutput = { uri ->
                            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                setDataAndType(uri, "video/*")
                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            try { context.startActivity(intent) } catch (_: Exception) {}
                        },
                        onCompare = { viewModel.navigateToComparison() },
                        onNew = { viewModel.onVideoSelected(emptyList()) }
                    )
                }
                is ProcessingState.Error -> {
                    ErrorCard(
                        message = ps.message,
                        detail = ps.detail
                    )
                }
                is ProcessingState.Cancelled -> {
                    InfoCard(message = "Processing was cancelled.")
                }
                is ProcessingState.Analyzing -> {
                    InfoCard(message = "Analyzing ${ps.fileName}...")
                }
                ProcessingState.Idle -> { /* nothing */ }
            }

            Spacer(Modifier.height(32.dp))

            // Privacy footer
            Text(
                text = "All processing happens locally on your device. No videos are uploaded.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}