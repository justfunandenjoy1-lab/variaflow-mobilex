package com.variaflow.mobile.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.variaflow.mobile.data.model.VideoInfo

@Composable
fun VideoInfoCard(info: VideoInfo) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Video Information", style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

            InfoRow("File Name", info.fileName)
            InfoRow("File Size", info.fileSizeFormatted)
            InfoRow("Duration", info.durationFormatted)
            InfoRow("Resolution", info.resolution)
            InfoRow("FPS", if (info.fps > 0) "%.1f fps".format(info.fps) else "Unknown")
            InfoRow("Video Codec", info.videoCodec)
            InfoRow("Audio Codec", info.audioCodec)
            InfoRow("Bitrate", info.bitrateFormatted)
            InfoRow("Container", info.containerFormat)
            InfoRow("Sample Rate", if (info.audioSampleRate > 0) "${info.audioSampleRate} Hz" else "N/A")
            InfoRow("Channels", if (info.audioChannels > 0) "${info.audioChannels}" else "N/A")
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium)
    }
}