package com.variaflow.mobile.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Pending
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.variaflow.mobile.data.model.ProcessingState
import com.variaflow.mobile.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BatchScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val state by viewModel.uiState.collectAsState()
    val infos = state.videoInfos
    val ps = state.processingState

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Batch Processing (${infos.size} files)") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (ps is ProcessingState.Processing) {
                LinearProgressIndicator(
                    progress = { ps.progressPercent / 100f },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Processing: ${ps.fileName} (${ps.currentFileIndex}/${ps.totalFiles})",
                    style = MaterialTheme.typography.bodyMedium)
                Text(ps.stage, style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = { viewModel.cancelProcessing() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Cancel")
                }
            }

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(infos) { info ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.padding(12.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = when {
                                    ps is ProcessingState.Completed && ps.outputFileNames.contains(info.fileName) ->
                                        Icons.Default.CheckCircle
                                    ps is ProcessingState.Processing && ps.fileName == info.fileName ->
                                        Icons.Default.Pending
                                    else -> Icons.Default.Pending
                                },
                                contentDescription = null,
                                tint = when {
                                    ps is ProcessingState.Completed && ps.outputFileNames.contains(info.fileName) ->
                                        MaterialTheme.colorScheme.primary
                                    ps is ProcessingState.Error -> MaterialTheme.colorScheme.error
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                }
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(info.fileName, style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium)
                                Text("${info.resolution}  •  ${info.fileSizeFormatted}  •  ${info.durationFormatted}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            if (ps !is ProcessingState.Processing && infos.isNotEmpty()) {
                Button(
                    onClick = { viewModel.processBatch() },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text("Process All Videos")
                }
            }
        }
    }
}