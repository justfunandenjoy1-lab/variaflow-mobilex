package com.variaflow.mobile.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.variaflow.mobile.ui.screens.*
import com.variaflow.mobile.viewmodel.MainViewModel

object Routes {
    const val HOME = "home"
    const val SETTINGS = "settings"
    const val COMPARISON = "comparison"
    const val BATCH = "batch"
}

@Composable
fun VariaFlowNavGraph(
    viewModel: MainViewModel,
    navController: NavHostController = rememberNavController()
) {
    val state by viewModel.uiState.collectAsState()

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(viewModel = viewModel, onNavigateToSettings = { navController.navigate(Routes.SETTINGS) })
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
        }
        composable(Routes.COMPARISON) {
            ComparisonScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
        }
        composable(Routes.BATCH) {
            BatchScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
        }
    }
}