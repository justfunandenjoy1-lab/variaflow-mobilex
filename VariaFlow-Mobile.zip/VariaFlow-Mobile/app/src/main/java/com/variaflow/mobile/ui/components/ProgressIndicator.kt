package com.variaflow.mobile.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.variaflow.mobile.data.model.ProcessingState

@Composable
fun ProcessingProgressCard(
    state: ProcessingState.Processing,
    onCancel: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Processing Video...", style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold)

            if (state.totalFiles > 1) {
                Text("File ${state.currentFileIndex} of ${state.totalFiles}: ${state.fileName}",
                    style = MaterialTheme.typography.bodyMedium)
            }

            LinearProgressIndicator(
                progress = { state.progressPercent / 100f },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                strokeCap = androidx.compose.ui.graphics.StrokeCap.Round
            )

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${state.progressPercent}%", style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold)
                Text(state.stage, style = MaterialTheme.typography.bodyMedium)
            }

            Button(
                onClick = onCancel,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                )
            ) {
                Text("Cancel")
            }
        }
    }
}