package com.variaflow.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.variaflow.mobile.ui.navigation.VariaFlowNavGraph
import com.variaflow.mobile.ui.theme.VariaFlowTheme
import com.variaflow.mobile.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VariaFlowTheme {
                val viewModel: MainViewModel = viewModel()
                VariaFlowNavGraph(viewModel = viewModel)
            }
        }
    }
}