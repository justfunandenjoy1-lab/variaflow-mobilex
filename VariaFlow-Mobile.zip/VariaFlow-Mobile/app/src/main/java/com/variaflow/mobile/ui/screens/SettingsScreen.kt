package com.variaflow.mobile.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.variaflow.mobile.data.model.*
import com.variaflow.mobile.ui.components.*
import com.variaflow.mobile.viewmodel.MainViewModel
import androidx.compose.runtime.collectAsState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    var settings by remember(state.settings) { mutableStateOf(state.settings) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Processing Settings") },
                navigationIcon = {
                    IconButton(onClick = {
                        viewModel.updateSettings(settings)
                        onBack()
                    }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Presets
            PresetSelector(
                selected = settings.preset,
                onSelect = { preset ->
                    settings = ProcessingSettings.forPreset(preset, state.currentVideoInfo)
                }
            )

            HorizontalDivider()

            // ---- VIDEO SECTION ----
            SectionTitle("Video")

            DropdownField(
                label = "Output Format",
                options = OutputFormat.entries.map { it.label },
                selectedIndex = settings.outputFormat.ordinal,
                onSelect = { settings = settings.copy(outputFormat = OutputFormat.entries[it]) }
            )

            DropdownField(
                label = "Resolution",
                options = ResolutionOption.entries.map { it.label },
                selectedIndex = settings.resolution.ordinal,
                onSelect = { settings = settings.copy(resolution = ResolutionOption.entries[it]) }
            )

            DropdownField(
                label = "Frame Rate (FPS)",
                options = FpsOption.entries.map { it.label },
                selectedIndex = settings.fps.ordinal,
                onSelect = { settings = settings.copy(fps = FpsOption.entries[it]) }
            )

            DropdownField(
                label = "Video Codec",
                options = VideoCodecOption.entries.map { it.label },
                selectedIndex = settings.videoCodec.ordinal,
                onSelect = { settings = settings.copy(videoCodec = VideoCodecOption.entries[it]) }
            )

            // Quality: CRF vs Bitrate
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text("Quality mode:", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.width(12.dp))
                FilterChip(
                    selected = settings.useCrf,
                    onClick = { settings = settings.copy(useCrf = true) },
                    label = { Text("CRF") }
                )
                Spacer(Modifier.width(8.dp))
                FilterChip(
                    selected = !settings.useCrf,
                    onClick = { settings = settings.copy(useCrf = false) },
                    label = { Text("Bitrate") }
                )
            }

            if (settings.useCrf) {
                SliderField(
                    label = "CRF (lower = better quality)",
                    value = settings.crfValue.toFloat(),
                    range = 0f..51f,
                    steps = 50,
                    onValueChange = { settings = settings.copy(crfValue = it.toInt()) },
                    displayValue = settings.crfValue.toString()
                )
            } else {
                SliderField(
                    label = "Video Bitrate",
                    value = settings.videoBitrateKbps.toFloat(),
                    range = 500f..20000f,
                    steps = 38,
                    onValueChange = { settings = settings.copy(videoBitrateKbps = it.toInt()) },
                    displayValue = "${settings.videoBitrateKbps} kbps"
                )
            }

            HorizontalDivider()

            // ---- AUDIO SECTION ----
            SectionTitle("Audio")

            DropdownField(
                label = "Audio Codec",
                options = AudioCodecOption.entries.map { it.label },
                selectedIndex = settings.audioCodec.ordinal,
                onSelect = { settings = settings.copy(audioCodec = AudioCodecOption.entries[it]) }
            )

            if (settings.audioCodec != AudioCodecOption.COPY && settings.audioCodec != AudioCodecOption.NONE) {
                SliderField(
                    label = "Audio Bitrate",
                    value = settings.audioBitrateKbps.toFloat(),
                    range = 32f..320f,
                    steps = 28,
                    onValueChange = { settings = settings.copy(audioBitrateKbps = it.toInt()) },
                    displayValue = "${settings.audioBitrateKbps} kbps"
                )

                DropdownField(
                    label = "Sample Rate",
                    options = SampleRateOption.entries.map { it.label },
                    selectedIndex = settings.sampleRate.ordinal,
                    onSelect = { settings = settings.copy(sampleRate = SampleRateOption.entries[it]) }
                )

                DropdownField(
                    label = "Channels",
                    options = ChannelOption.entries.map { it.label },
                    selectedIndex = settings.channels.ordinal,
                    onSelect = { settings = settings.copy(channels = ChannelOption.entries[it]) }
                )
            }

            HorizontalDivider()

            // ---- CONTAINER SECTION ----
            SectionTitle("Container")

            DropdownField(
                label = "Output Container",
                options = OutputFormat.entries.map { it.label },
                selectedIndex = settings.outputFormat.ordinal,
                onSelect = { settings = settings.copy(outputFormat = OutputFormat.entries[it]) }
            )

            Spacer(Modifier.height(16.dp))

            Button(
                onClick = {
                    viewModel.updateSettings(settings)
                    onBack()
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text("Apply Settings", style = MaterialTheme.typography.titleLarge)
            }

            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary
    )
}