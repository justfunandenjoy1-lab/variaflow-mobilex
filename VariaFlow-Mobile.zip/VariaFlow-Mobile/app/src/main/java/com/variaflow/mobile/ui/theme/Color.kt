package com.variaflow.mobile.ui.theme

import androidx.compose.ui.graphics.Color

val Indigo80 = Color(0xFFB0C4FF)
val IndigoGrey80 = Color(0xFFC5C6D0)
val Teal80 = Color(0xFF80DEEA)

val Indigo40 = Color(0xFF3F51B5)
val IndigoGrey40 = Color(0xFF5F6368)
val Teal40 = Color(0xFF00897B)

val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val LightBackground = Color(0xFFFAFAFA)
val LightSurface = Color(0xFFFFFFFF)
val WarningAmber = Color(0xFFFFB300)
val SuccessGreen = Color(0xFF4CAF50)
val ErrorRed = Color(0xFFE53935)