package com.variaflow.mobile.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.variaflow.mobile.viewmodel.MainViewModel
import androidx.compose.runtime.collectAsState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComparisonScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val state by viewModel.uiState.collectAsState()
    val original = state.currentVideoInfo

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Before / After Comparison") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            original?.let { info ->
                ComparisonCard(
                    title = "ORIGINAL",
                    resolution = info.resolution,
                    fps = if (info.fps > 0) "${info.fps.toInt()} fps" else "Unknown",
                    bitrate = info.bitrateFormatted,
                    size = info.fileSizeFormatted,
                    codec = "${info.videoCodec} / ${info.audioCodec}"
                )

                Icon(
                    imageVector = Icons.Default.ArrowDownward,
                    contentDescription = null,
                    modifier = Modifier.align(androidx.compose.ui.Alignment.CenterHorizontally),
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            val ps = state.processingState
            if (ps is com.variaflow.mobile.data.model.ProcessingState.Completed) {
                ComparisonCard(
                    title = "OUTPUT",
                    resolution = state.settings.resolution.label,
                    fps = state.settings.fps.label,
                    bitrate = if (state.settings.useCrf)
                        "CRF ${state.settings.crfValue}"
                    else "${state.settings.videoBitrateKbps} kbps",
                    size = "Saved to Movies/VariaFlow/Output",
                    codec = "${state.settings.videoCodec.label} / ${state.settings.audioCodec.label}"
                )
            } else {
                InfoCard(message = "Process a video first to see the comparison.")
            }

            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
fun ComparisonCard(
    title: String,
    resolution: String,
    fps: String,
    bitrate: String,
    size: String,
    codec: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary)
            InfoRow("Resolution", resolution)
            InfoRow("FPS", fps)
            InfoRow("Bitrate", bitrate)
            InfoRow("Size", size)
            InfoRow("Codec", codec)
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}